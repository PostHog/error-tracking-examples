export type PostHogReactNativePluginMap = {
    [key: string]: any;
};
export interface PostHogReactNativePluginSessionReplayConfig {
    enabled?: boolean;
    sdkReplayConfig?: PostHogReactNativePluginMap;
    decideReplayConfig?: PostHogReactNativePluginMap;
}
export interface PostHogReactNativePluginExceptionStepsConfig {
    enabled?: boolean;
    maxBytes?: number;
}
export interface PostHogReactNativePluginErrorTrackingConfig {
    nativeAutocapture?: boolean;
    exceptionSteps?: PostHogReactNativePluginExceptionStepsConfig;
}
export interface PostHogReactNativePluginConfig {
    sessionReplay?: PostHogReactNativePluginSessionReplayConfig;
    errorTracking?: PostHogReactNativePluginErrorTrackingConfig;
}
export declare function setup(sessionId: string, sdkOptions: PostHogReactNativePluginMap, pluginConfig?: PostHogReactNativePluginConfig): Promise<void>;
export declare function start(sessionId: string, sdkOptions: PostHogReactNativePluginMap, sdkReplayConfig: PostHogReactNativePluginMap, decideReplayConfig: PostHogReactNativePluginMap): Promise<void>;
export declare function startSession(sessionId: string): Promise<void>;
export declare function endSession(): Promise<void>;
export declare function isEnabled(): Promise<boolean>;
export declare function identify(distinctId: string, anonymousId: string): Promise<void>;
export declare function startRecording(resumeCurrent: boolean): Promise<void>;
export declare function stopRecording(): Promise<void>;
export declare function addExceptionStep(message: string, properties?: PostHogReactNativePluginMap): Promise<void>;
export interface PostHogReactNativePluginModule {
    setup: (sessionId: string, sdkOptions: PostHogReactNativePluginMap, pluginConfig?: PostHogReactNativePluginConfig) => Promise<void>;
    /**
     * Legacy session replay setup entrypoint. Prefer setup() for new native features.
     */
    start: (sessionId: string, sdkOptions: PostHogReactNativePluginMap, sdkReplayConfig: PostHogReactNativePluginMap, decideReplayConfig: PostHogReactNativePluginMap) => Promise<void>;
    startSession: (sessionId: string) => Promise<void>;
    endSession: () => Promise<void>;
    isEnabled: () => Promise<boolean>;
    identify: (distinctId: string, anonymousId: string) => Promise<void>;
    startRecording: (resumeCurrent: boolean) => Promise<void>;
    stopRecording: () => Promise<void>;
    addExceptionStep: (message: string, properties?: PostHogReactNativePluginMap) => Promise<void>;
}
declare const PostHogReactNativePlugin: PostHogReactNativePluginModule;
export default PostHogReactNativePlugin;
//# sourceMappingURL=index.d.ts.map