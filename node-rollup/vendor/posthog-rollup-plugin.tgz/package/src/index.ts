import type { Plugin, OutputOptions, OutputAsset, OutputChunk } from 'rollup'
import { PluginConfig, resolveConfig, runSourcemapCli } from '@posthog/plugin-utils'
import path from 'node:path'
import fs from 'node:fs/promises'

// Re-export for backward compatibility
export type PostHogRollupPluginOptions = PluginConfig

// The `config` hook is Vite-specific: Vite runs it before the build to force sourcemap
// generation, while Rollup ignores unknown hooks.
type PostHogRollupPlugin = Plugin & {
    config: () => { build: { sourcemap: boolean | 'hidden' } } | undefined
}

// `output.sourcemapDebugIds` landed in rollup 4.28.0; older versions warn on unknown options.
export function rollupSupportsDebugIds(rollupVersion: string | undefined): boolean {
    if (!rollupVersion) {
        return true
    }
    const [major, minor] = rollupVersion.split('.').map(Number)
    if (Number.isNaN(major) || Number.isNaN(minor)) {
        return true
    }
    return major > 4 || (major === 4 && minor >= 28)
}

export default function posthogRollupPlugin(userOptions: PostHogRollupPluginOptions): Plugin {
    const posthogOptions = resolveConfig(userOptions)
    const plugin: PostHogRollupPlugin = {
        name: 'posthog-rollup-plugin',

        config() {
            if (!posthogOptions.sourcemaps.enabled) return

            return {
                build: {
                    sourcemap: posthogOptions.sourcemaps.deleteAfterUpload ? 'hidden' : true,
                },
            }
        },

        outputOptions: {
            order: 'post',
            handler(options: OutputOptions) {
                if (!posthogOptions.sourcemaps.enabled) return options

                const next: OutputOptions = {
                    ...options,
                    sourcemap: posthogOptions.sourcemaps.deleteAfterUpload ? 'hidden' : true,
                }
                // The CLI adopts bundler-emitted debug ids as chunk ids under --release-mode=event.
                // Gated on the flag: older CLI versions mishandle maps that carry a debugId.
                const rollupVersion = (this as { meta?: { rollupVersion?: string } } | undefined)?.meta?.rollupVersion
                if (posthogOptions.sourcemaps.noReleaseBind && rollupSupportsDebugIds(rollupVersion)) {
                    next.sourcemapDebugIds = true
                }
                return next
            },
        },

        writeBundle: {
            // Write bundle is executed in parallel, make it sequential to ensure correct order
            sequential: true,
            async handler(options: OutputOptions, bundle: { [fileName: string]: OutputAsset | OutputChunk }) {
                if (!posthogOptions.sourcemaps.enabled) return
                const chunks: { [fileName: string]: OutputChunk } = {}
                const filePaths: string[] = []
                const basePaths: string[] = []

                if (options.dir) {
                    basePaths.push(options.dir)
                }

                if (options.file) {
                    basePaths.push(path.dirname(options.file))
                }

                for (const fileName in bundle) {
                    const chunk = bundle[fileName]
                    const isJsFile = /\.(js|mjs|cjs)$/.test(fileName)
                    if (chunk.type === 'chunk' && isJsFile) {
                        const chunkPath = path.resolve(...basePaths, fileName)
                        chunks[chunkPath] = chunk
                        filePaths.push(chunkPath)
                    }
                }

                if (filePaths.length === 0) {
                    console.log(
                        'No chunks found, skipping sourcemap processing for this stage. Your build may be multi-stage and this stage may not be relevant'
                    )
                    return
                }

                await runSourcemapCli(posthogOptions, { filePaths })

                // we need to update code for others plugins to work
                await Promise.all(
                    Object.entries(chunks).map(([chunkPath, chunk]) =>
                        fs.readFile(chunkPath, 'utf8').then((content) => {
                            chunk.code = content
                        })
                    )
                )
            },
        },
    }
    return plugin
}
